from distutils.core import setup

setup(
    name='Oneshot-TF',
    version='0.1dev',
    packages=['oneshot-tf',],
)
