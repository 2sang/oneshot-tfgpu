import yaml
import docker

def main():
    with open('conf.yaml', 'r') as f:
        conf = yaml.load(f)
    conf.
        
if __name__ == "__main__":
    main()
